package com.learningjavaandroid.javalogicaland;

public class JavaLogicalAND {
    public static void main(String[] args) {
        int age = 18;
        boolean isCitizen = true;
        boolean notAFelon = false;

        if ( (age >= 18) && (isCitizen) && (notAFelon) ) {
            System.out.println("Can vote!");
        }else {
            System.out.println("Can't vote!");
        }
    }
}