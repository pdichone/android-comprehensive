package com.learningjavaandroid.javaforloop;

public class JavaForLoop {
    public static void main(String[] args) {


        // Finding multiples of 2
        int i = 0; // initializing i outside the for loop
        for (; i < 1000; i++) {
            if (i % 2 == 0) {
                System.out.println(i + " is a multiple of 2");
            }
        }

        //Initializing i inside the for loop
//        for (int i = 0; i < 10 ; i++) {
//            System.out.println(i);
//        }
    }
}