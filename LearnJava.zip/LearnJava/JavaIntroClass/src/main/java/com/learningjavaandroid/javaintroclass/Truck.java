package com.learningjavaandroid.javaintroclass;

public class Truck extends Vehicle {

    private int horsePower;

    public Truck(String color, String make, int modelYear, int weight, int horsePower) {
        super(color, make, modelYear, weight);
        this.horsePower = horsePower;
    }

    public int getHorsePower() {
        return horsePower;
    }

    public void setHorsePower(int horsePower) {
        this.horsePower = horsePower;
    }


    public void showSuperBehavior() {
         super.drive();
    }

    @Override
    public void start() {
        System.out.println("Vroom Vroom like a Truck!");
        //super.start();
    }
}
