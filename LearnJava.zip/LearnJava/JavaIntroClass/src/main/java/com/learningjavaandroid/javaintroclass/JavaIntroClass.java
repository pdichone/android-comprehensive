package com.learningjavaandroid.javaintroclass;

public class JavaIntroClass {
    public static void main(String[] args) {

        /**
         *  Java Objects/Classes and Inheritance
         *
         */

        Car myCar = new Car("Blue", "Toyota", 1978, 78776);

//        myCar.setMake("Toyota");
//        myCar.setModelYear(1978);
//        myCar.setWeight(89787);
//        myCar.setColor("Blue");

        System.out.println(myCar.getColor() + " " + myCar.getMake() + " "
                + " " + myCar.getModelYear() + " " + myCar.getWeight());

        Truck myTruck = new Truck("Black", "Ford", 1999, 8900, 12000);
//        myTruck.setMake("Ford");
//        myTruck.setModelYear(2019);
//        myTruck.setWeight(898);
//        myTruck.setColor("Black");
//        myTruck.setHorsePower(12000);
//        myTruck.start();
//        myTruck.showSuperBehavior();

        System.out.println(myTruck.getColor() + " " + myTruck.getMake() + " "
                + " " + myTruck.getModelYear() + " " + myTruck.getWeight() + " HP: " +
                myTruck.getHorsePower());


        System.out.println(myCar.getColor());

        myCar.start();
        myCar.setColor("Blue");
        myCar.setMake("Mazda");

        System.out.println("My car is a " + myCar.getColor() + " " + myCar.getMake() + " year: " + myCar.getModelYear());
    }
}