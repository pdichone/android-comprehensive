package com.learningjavaandroid.javawhileloop;

public class JavaWhileLoop {
    public static void main(String[] args) {
       // Destination mile 10 - while loop

        int destination = 10;
        int counter = 0;

        while (counter < destination){
            System.out.println("Keep driving");
            counter++;

        }
        System.out.println("You've arrived at mile " + counter);
    }
}