package com.learningjava.firstjava;

public class Vehicle {

    private String color;
    private String make;
    private int modelYear;
    private int weight;


    public Vehicle(String color, String make, int modelYear, int weight) {

        this.color = color;
        this.make = make;
        this.modelYear = modelYear;
        this.weight = weight;

    }



    public void start() {
        System.out.println("Starting the car...");
    }
    public void drive() {
        System.out.println("Car moving...");
    }

    public void stop() {
        System.out.println("Stopping for gas...");
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public int getModelYear() {
        return modelYear;
    }

    public void setModelYear(int modelYear) {
        this.modelYear = modelYear;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        int defWeight = 1000;
        if (weight <= 0){
            this.weight = defWeight;
        }else {
            this.weight = weight;
        }

    }
}
