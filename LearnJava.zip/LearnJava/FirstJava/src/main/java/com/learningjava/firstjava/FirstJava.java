package com.learningjava.firstjava;

public class FirstJava {

    static boolean search(double[] data, double target) {
        int i;  // O( 1) operation
        System.out.println("Start Searching...");

        for (i = 0; i < data.length; i++) {
            // for loop will execute the body at least n times (input size) - worst-case scenario
            //check to see if the target is at data[i]
            System.out.println(data[i]);
            if (data[i] == target) return true;

        }
        // no match found, return false.
        return false; // O(1) operation


    }

    public static void printStars(int stars) {
        int lines;
        for (lines = 1; lines <= 2; lines++) {
            for (int i = 1; i <= stars; i++)
                System.out.print("*");
            System.out.println();
        }
    }

     /*
         Write a method that prints the numbers from 1 to 100.
         But for multiples of three print “Fizz” instead of the number and for the multiples of five print “Buzz”.
         For numbers which are multiples of both three and five print “FizzBuzz”
         */

        /*
          Clarification questions:
            1. are the numbers inclusive 1 and 100?
            2. is it okay to pass a parameter to the function, to make it more flexible?
        */
      public static void printFizzBuzz(int upperBound) {

          for (int i = 1; i <= upperBound; i++) {
              // This approach gives the wrong answers
//              if (i%3 == 0) {
//                  System.out.println("Fizz");
//              }else if (i%5 == 0) {
//                  System.out.println("Buzz");
//              }else if ( ((i % 5) == 0) && ((i % 3) == 0)) {
//                  System.out.println("FizzBuzz");
//              }else
//                  System.out.println(i);

//              if (((i % 5) == 0) && ((i % 3) == 0)) {
//                  System.out.println("FizzBuzz");
//
//              }else if ( i % 3 == 0) {
//                   System.out.println("Fizz");
//               }else if (i % 5 == 0) {
//                   System.out.println("Buzz");
//               }else {
//                   System.out.println(i);
//               }

              // or
              if ((i % 15 == 0)) { // if a number is mult of 5 and 3, that num is also mult of 15
                  System.out.println("FizzBuzz");
              }else if ( i % 3 == 0) {
                  System.out.println("Fizz");
              }else if (i % 5 == 0) {
                  System.out.println("Buzz");
              }else {
                  System.out.println(i);
              }

          }
      }

    public static void main(String[] args) {

        printFizzBuzz(100);

       // System.out.println( search( new double[]{45, 10, 90, 89}, 89));

//        String name = "Lucy";
//
//        System.out.println(Math.PI);
//
//        StringBuilder stringBuilder = new StringBuilder();
//        stringBuilder.append("Hey my name is " +name);
//        stringBuilder.append(" and I'm 45 years old!");
//
//        System.out.println(stringBuilder);


    }


}


//    Car myCar = new Car();
//        myCar.setMake("Toyota");
//                myCar.setModelYear(1978);
//                myCar.setWeight(3400);
//                myCar.setColor("Blue");
//
//                Truck myTruck = new Truck();
//                myTruck.setMake("Ford");
//                myTruck.setModelYear(2019);
//                myTruck.setWeight(7400);
//                myTruck.setColor("Black");
//                myTruck.start();
//                myTruck.setHorsePower(12000);
//
//
//                System.out.println(myTruck.getColor() + " " + myTruck.getMake() + " "
//                + " " + myTruck.getModelYear() + " " + myTruck.getWeight() + " HP: "
//                + myTruck.getHorsePower());


//        System.out.println(myCar.getColor() + " " + myCar.getMake() + " "
//         + " " + myCar.getModelYear() + " " + myCar.getWeight());

//        double dPie = 3.14 / 212;
//        float fPie = 3.14f / 212;
//
//
//        boolean isHappy = true;
//        boolean isDone = false;
//        char c = 'C';
//
//        byte aByte = -128; //range values -128 to 127
//        short aShort = 30000; // range values -32768 to 32767
//
//        long aLong = 76764434;
//
//        System.out.println("Double location: " + dPie);
//        System.out.println("Float location: " + fPie);
//
//        //Tester
//        System.out.println(1.0 / 3.0);
//        System.out.println(1.0 - 0.9);
//        System.out.println(3.14 - 1.9); // 1.2400000000000002 - 16 decimal places

//explanation
        /*

        MUST READ JIM'S ANSWER TO HELP EXPLAIN THIS: https://stackoverflow.com/questions/3334168/how-many-decimal-places-in-a-double-java#:~:text=The%20number%20of%20decimal%20places%20in%20a%20double%20is%2016.
         When  calculations involve floating-point numbers are approximate because they are not stored with complete
         precision in memory.

         Maybe give BigDecimal a go as an alternative to getting rounded numbers?: https://www.geeksforgeeks.org/bigdecimal-class-java/

         Other primitive types(except boolean) are fixed-point numbers. Unlike fixed point numbers, floating point numbers will most of the times return an answer with a small error (around 10^-19) This is the reason why we end up with 0.009999999999999998 as the result of 0.04-0.03 in the above example.
         */

/*
       One a string type called firstName and assign “James” to it.
       Second, also a String type called lastName and assign “Bond” to it.
       The third one is an integer type called age and assign 45 to it.
       Then print out a text that reads:

       “Hi, my name is James Bond, and I am 45 years old.”

      The challenge here is you’ll need to pass the variables you’ve declared previously in the println()
      as variables, so the contents of the variables are extracted out when you run the program.
      Essentially, your print out should look like this:

       System.out.println(“Hi, my name is firstName lastName, and I am age years old.”)


   Hint: Google “java string concatenation operator.”

     */


//      ArrayList<Integer> ages = new ArrayList<>();
//      ArrayList<String> names = new ArrayList<>();
//
//      names.add("Carla");
//      names.add(1, "Lucia");
//      names.remove("Lucia");
//
//
//        for (int i = 0; i < names.size() ; i++) {
//            System.out.println(names.get(i));
//        }

//        for (int i = 10; i >= 1; i--) {
//            System.out.print(i);
//
//
//        }
//char[] arr = num.toCharArray();
//        System.out.println(arr);
//        int area = rectArea(-30, -10);
//        System.out.println(area);
//

/*


String is an Object + Math class!

 String name = "Lucy";

        System.out.println(Math.PI);

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Hey my name is " + name);
        stringBuilder.append(" and I'm 45 years old!");

        System.out.println(stringBuilder);




Constructors and Inheritance

        Car myCar = new Car("Blue", "Toyota", 1978, 78776);

//        myCar.setMake("Toyota");
//        myCar.setModelYear(1978);
//        myCar.setWeight(89787);
//        myCar.setColor("Blue");

        System.out.println(myCar.getColor() + " " + myCar.getMake() + " "
                + " " + myCar.getModelYear() + " " + myCar.getWeight());

        Truck myTruck = new Truck("Black", "Ford", 1999, 8900, 12000);
//        myTruck.setMake("Ford");
//        myTruck.setModelYear(2019);
//        myTruck.setWeight(898);
//        myTruck.setColor("Black");
//        myTruck.setHorsePower(12000);
//        myTruck.start();
//        myTruck.showSuperBehavior();

        System.out.println(myTruck.getColor() + " " + myTruck.getMake() + " "
                + " " + myTruck.getModelYear() + " " + myTruck.getWeight() + " HP: " +
                 myTruck.getHorsePower());
  The String Class

   String name = "Lucy";
//       String name = new String("Lucy");

        if (name.contains("D"))
            System.out.println("Yes, there's a y in Lucy");

        System.out.println(name.charAt(0));

        System.out.println(name.concat("'s birthday"));

        for (int i = 0; i < name.length() ; i++) {
            System.out.println(name.charAt(i));

        }


Objects - Getters and Setters
 Car myCar = new Car("Red", "Toyota", 1989, 100);
        myCar.setWeight(-10);


        System.out.println(myCar.getColor() + " "+ myCar.getMake() + " "+ myCar.getModelYear() + " "
                + myCar.getWeight() );


Methods in Java
public static int sum(int a, int b) {

        return a + b;
    }

//  new FirstJava().sum();
        int total = sum(34, 11);
        System.out.println("The total is " + total*10);


Class and Objects in Java
Car myCar = new Car("Red", "Toyota", 1989); // the actual object!

        System.out.println(myCar.color);

        myCar.start();
         myCar.color = "Blue";
         myCar.make = "Mazda";

        System.out.println("My car is a " + myCar.color + " " + myCar.make + " year: " + myCar.modelYear);
Arrays!
//int[] ages = new int[5];
        int[] ages = {10, 9, 1, 8, 2};
        String[] pets = {"Cat", "Dog", "Giraffe!", "Parrot"};


        for (int i = 0; i < pets.length ; i++) {
            //if (ages[i] % 2 == 0)
             System.out.println(pets[i]);
        }
   ====== Supplemental Exercises ======


    public static String showFullName(String firstName, String lastName) {
         return "Here's my full name " + firstName + " " + lastName;
    }
    System.out.println(showFullName("Gina", "Alexander."));
        //String object exercise - How many characters in a string and and don't account for spaces
        String greet = "Hello, friend! How are you doing?";

        if (greet.contains("Hello ")) {
            System.out.println("Yep!");
        }else {
            System.out.println("Nope!");
        }

        System.out.println(greet);

        //Calculate the average age
        int[] ages = {20, 30, 100, 45, 10, 33};

        int ageSum = 0;
        int averageAge = 0;
        for (int i = 0; i < ages.length ; i++) {
            //ageSum = ageSum + ages[i];
            ageSum += ages[i];

            //calculate average
            averageAge = ageSum / ages.length;


        }
        System.out.println("The average age is: " + averageAge);
        //System.out.println(avgPrice);
        for (int i = 10; i > 1 ; i--) {
            System.out.println(i);

        }


//        int i = 0;
//        for (; i < 1000; i++) {
//            if (i % 2 == 0) {
//                System.out.println( i + " is a multiple of 2" );
//            }
//        }


 */

/*
do while
  int limit = 10;
        int counter = 1;

        do {
            System.out.println("We keep counting...");
            counter++;

       }while (counter > limit);
 */


/*
   char grade = 'A';

//        if (grade == 'A') {
//            System.out.println("A is for Awesome!");
//        }else if (grade == 'B'){
//            System.out.println("B is for Beautifully done!");
//        }else if (grade == 'C') {
//            System.out.println("C is for Careless.");
//        }else if (grade == 'F') {
//            System.out.println("F is for Future Unknown.");
//        }

        switch (grade) {
            case 'A':
                System.out.println("A is for Awesome!");
                System.out.println("Made mom proud.");
                break;
            case 'B':
                System.out.println("B is for Beautifully done!");
                break;
            case 'C':
                System.out.println("C is for Careless.");
                break;
            default:
                System.out.println("F is for Future Unknown!");

        }
 */
/*
 Bank - If-else statements
 int bankAct = 1900;

        if (bankAct != 1000) {
             System.out.println("Nope. Just stay home. Vegas is too expensive.");
        }else {
            System.out.println("You're doing alright. Have fun!");
        }


 */

/*
  Destination mile 10 - while loop
  int destination = 10;
        int counter = 0;

        while (counter < destination){
            System.out.println("Keep driving");
            counter++;

        }
        System.out.println("You've arrived at mile " + counter);
 */

/*
   Weight on Planet X exercise

    double weight = 190;
       System.out.println("Object's weight on Earth is " + weight);

        double venusWeight = weight * 0.91;
        System.out.println("Object's weight on Venus is " + venusWeight);

        double marsWeight = weight * 0.38;
        System.out.println("Object's weight on Mars is " + marsWeight);

        double jupiterWeight = weight * 2.34;
        System.out.println("Object's weight on Jupiter is " + jupiterWeight);

        double saturnWeight = weight * 0.93;
        System.out.println("Object's weight on Saturn is " + saturnWeight);


        ====== Aligned ======

        double weight = 190;
        System.out.println("Object's weight on Earth is     " + weight);

        double venusWeight = weight * 0.91;
        System.out.println("Object's weight on Venus is     " + venusWeight);

        double marsWeight = weight * 0.38;
        System.out.println("Object's weight on Mars is       " + marsWeight);

        double jupiterWeight = weight * 2.34;
        System.out.println("Object's weight on Jupiter is   "+ jupiterWeight);

        double saturnWeight = weight * 0.93;
        System.out.println("Object's weight on Saturn is    "+ saturnWeight);
 */

/*
 double a = 10;
        double b = 5;
        double sum = a+b;
        double result = a-b;
        double divisionResult = a/b;
        double multiResult = a*b;
        double remainder = a%b;
        double total = 100 + (a*10);
        int age = 10;
        age++;

        int y = 10* (4+5);
        int x = 3*2+4*10/2;

        System.out.println("Test " + x);


        System.out.println("Result is " + result);
        System.out.println("The sum of " + a + " and " + b + " is " + sum + ".");
        System.out.println("Division result " + divisionResult);
        System.out.println("Multi result " + multiResult);
        System.out.println("Remainder " + remainder);
        System.out.println("Total " + total);
        System.out.println("Increment " + age);
 */











/*
       double dPie = 3.14 / 212;
       float fPie = 3.14f / 212;

       boolean isHappy = true;
       boolean isDone = false;
       char c = 'C';

       byte aByte = -128; //range values -128 to 127
        short aShort = 30000; // range values -32768 to 32767

        long aLong = 76764434;

       System.out.println("Double location: " + dPie);
        System.out.println("Float location: " + fPie);
 */



/*
  String name = "Paulo";
        String bio = "I grew up in a small town called HappyVille. I was a very happy child in HappyVille.";
        int age = 100;
        int siblings = 13;

        System.out.println("Hi, I'm " + name + " and I'm " + age + " years old. " + bio + " I have" +
                 siblings + " brothers and sisters.");
 */


/*
        String firstName = "James";
        String lastName = "Bond";
        int age = 45;


        System.out.println("Hi, my name is " +firstName+ " " +lastName+ " and I am " +age+ " years old.");
 */

    /*
       One a string type called firstName and assign “James” to it.
       Second, also a String type called lastName and assign “Bond” to it.
       The third one is an integer type called age and assign 45 to it.
       Then print out a text that reads:

       “Hi, my name is James Bond, and I am 45 years old.”

      The challenge here is you’ll need to pass the variables you’ve declared previously in the println()
      as variables, so the contents of the variables are extracted out when you run the program.
      Essentially, your print out should look like this:

       System.out.println(“Hi, my name is firstName lastName, and I am age years old.”)


   Hint: Google “java string concatenation operator.”

     */