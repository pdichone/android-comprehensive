package com.learningjavaandroid.javaoperators;

public class JavaOperators {
    public static void main(String[] args) {
        double a = 10;
        double b = 5;
        double sum = a+b;
        double result = a-b;
        double divisionResult = a/b;
        double multiResult = a*b;
        double remainder = a%b;
        double total = 100 + (a*10);
        int age = 10;
        age++;

        int y = 10* (4+5);
        int x = 3*2+4*10/2;

        System.out.println("Test " + x);


        System.out.println("Result is " + result);
        System.out.println("The sum of " + a + " and " + b + " is " + sum + ".");
        System.out.println("Division result " + divisionResult);
        System.out.println("Multi result " + multiResult);
        System.out.println("Remainder " + remainder);
        System.out.println("Total " + total);
        System.out.println("Decrement " + age);
    }
}