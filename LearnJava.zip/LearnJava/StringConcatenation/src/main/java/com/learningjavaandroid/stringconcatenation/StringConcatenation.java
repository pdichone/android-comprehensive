package com.learningjavaandroid.stringconcatenation;

public class StringConcatenation {
    public static void main(String[] args) {
         /*
       One a string type called firstName and assign “James” to it.
       Second, also a String type called lastName and assign “Bond” to it.
       The third one is an integer type called age and assign 45 to it.
       Then print out a text that reads:

       “Hi, my name is James Bond, and I am 45 years old.”

      The challenge here is you’ll need to pass the variables you’ve declared previously in the println()
      as variables, so the contents of the variables are extracted out when you run the program.
      Essentially, your print out should look like this:

       System.out.println(“Hi, my name is firstName lastName, and I am age years old.”)


        Hint: Google “java string concatenation operator.”

     */


        String firstName = "James";
        String lastName = "Bond";
        int age = 45;


        System.out.println("Hi, my name is " +firstName+ " " +lastName+ " and I am " +age+ " years old.");
    }
}