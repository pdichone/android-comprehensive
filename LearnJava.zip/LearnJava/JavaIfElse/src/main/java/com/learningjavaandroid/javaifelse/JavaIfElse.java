package com.learningjavaandroid.javaifelse;

public class JavaIfElse {

    public static void main(String[] args) {
       // Bank - If-else statements
        int bankAct = 1900;

        if (bankAct != 1000) {
            System.out.println("Nope. Just stay home. Vegas is too expensive.");
        }else {
            System.out.println("You're doing alright. Have fun!");
        }
    }
}