package com.learningjavaandroid.javaprimitives;

public class JavaPrimitives {
    public static void main(String[] args) {
        /**
         *  doubles and bytes in Java
         *  Double are more precise than integers
         */
        double dPie = 3.14 / 212;
        float fPie = 3.14f / 212;

        boolean isHappy = true;
        boolean isDone = false;
        char c = 'C';

        byte aByte = -128; //range values -128 to 127
        short aShort = 30000; // range values -32768 to 32767

        long aLong = 76764434;

        System.out.println("Double location: " + dPie);
        System.out.println("Float location: " + fPie);
    }
}