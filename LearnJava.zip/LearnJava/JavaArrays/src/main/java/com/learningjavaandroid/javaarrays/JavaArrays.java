package com.learningjavaandroid.javaarrays;

public class JavaArrays {
    public static void main(String[] args) {
       // Java Arrays
        //int[] ages = new int[5];
        int[] ages = {10, 9, 1, 8, 2};
        String[] pets = {"Cat", "Dog", "Giraffe!", "Parrot"};


        for (int i = 0; i < pets.length ; i++) {
            //if (ages[i] % 2 == 0)
            System.out.println(pets[i]);
        }
    }
}