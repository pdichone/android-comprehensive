package com.learningjavaandroid.javaconstructoroverloading;

public class Rectangle {
    private double length;
    private double width;
    private String name;

    public Rectangle(double length, double width, String name) {
        this.length = length;
        this.width = width;
        this.name = name;
    }

    public Rectangle() {
    }

    public void print() {
        System.out.println("Great Rectangle");
    }

    public void print(String message) {
        System.out.println("The area of the rectangle " + area() +
                 "and here's a message " + message);
    }
    public void print(String message, String color) {
        System.out.println("The area of the rectangle " + area() +
                "and here's a message " + message + " the color of the rectangle is " + color);
    }

    public double area() {
         return getLength() * getWidth();
    }


    public Rectangle(String name) {
        this.name = name;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
