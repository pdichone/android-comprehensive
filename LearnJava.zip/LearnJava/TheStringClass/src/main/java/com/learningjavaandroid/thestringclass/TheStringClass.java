package com.learningjavaandroid.thestringclass;

public class TheStringClass {
    public static void main(String[] args) {
        String name = "Lucy";
//       String name = new String("Lucy");

        if (name.contains("D"))
            System.out.println("Yes, there's a y in Lucy");

        System.out.println(name.charAt(0));

        System.out.println(name.concat("'s birthday"));

        for (int i = 0; i < name.length() ; i++) {
            System.out.println(name.charAt(i));

        }

    }
}