package com.learningjavaandroid.javaarraylist;

import java.util.ArrayList;

public class JavaArrayList {
    public static void main(String[] args) {
        ArrayList<String> names = new ArrayList<>();
        names.add(0, "Carla");
        names.add("Lucia");

        names.remove("Carla");
        names.remove(0);

        for (int i = 0; i < names.size(); i++) {

            System.out.println(names.get(i));
        }


        ArrayList<Integer> ages = new ArrayList<>();

        ages.add(45);
        System.out.println(ages.get(0));
    }
}