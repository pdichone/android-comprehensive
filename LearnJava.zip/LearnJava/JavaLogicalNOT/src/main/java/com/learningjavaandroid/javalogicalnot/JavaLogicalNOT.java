package com.learningjavaandroid.javalogicalnot;

public class JavaLogicalNOT {
    public static void main(String[] args) {
        boolean isFunny = true;

        if (!isFunny) {
            System.out.println("Not funny");
        }else {
            System.out.println("Funny");
        }

        int age = 23;
        if ( !(age > 10) || (isFunny == true) && (age < 89) ) {

        }else {
            System.out.println("Not true");
        }
    }
}