package com.learningjavaandroid.javamethods;

public class JavaMethods {

    public static void main(String[] args) {
        //  new FirstJava().sum();
        int total = sum(34, 11);
        System.out.println("The total is " + total*10);
    }

    public static int sum(int a, int b) {

        return a + b;
    }

}