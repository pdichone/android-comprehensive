package com.bawp.parks.adapter;

import com.bawp.parks.model.Park;

public interface OnParkClickListener {
    void onParkClicked(Park park);
}
