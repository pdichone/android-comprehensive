package com.bawp.fruitlist;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText enterFruit;
    private TextView fruitText;
    private ScrollView scrollView;
    private Button addButton;
    private StringBuilder stringBuilder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fruit_list);
        enterFruit = findViewById(R.id.enter_fruit);
        fruitText = findViewById(R.id.fruit_text_view);
        scrollView = findViewById(R.id.scrollview);
        stringBuilder = new StringBuilder();

        // Set textview background color
        fruitText.setBackgroundColor(Color.rgb(244,81,30));


        addButton = findViewById(R.id.add_fruit);
        addButton.setOnClickListener(this::addFruit);

    }
    private void addFruit(View v) {



        stringBuilder.append("\n");
        stringBuilder.append(enterFruit.getText().toString().trim());

        fruitText.setText(stringBuilder);

        // Clear editText
        enterFruit.setText("");

    }
}